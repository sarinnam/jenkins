// Skin specific Javascript
if ("scImgMgr" in window) scImgMgr.fOverAlpha=.9;
